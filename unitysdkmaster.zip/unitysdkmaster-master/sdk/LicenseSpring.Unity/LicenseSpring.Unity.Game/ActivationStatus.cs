﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LicenseSpring.Unity.Game
{
    public enum ActivationStatus
    {
        Trial,
        Registered,
        Expired,
        Offline,
        Unknown
    }
}
