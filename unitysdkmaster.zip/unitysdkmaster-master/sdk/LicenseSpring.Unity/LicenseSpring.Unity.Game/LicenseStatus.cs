﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LicenseSpring.Unity.Game
{
    public enum LicenseStatus
    {
        Active,
        InActive,
        Unknown
    }
}
